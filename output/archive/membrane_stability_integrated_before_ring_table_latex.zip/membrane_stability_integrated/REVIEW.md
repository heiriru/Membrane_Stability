# Editorial and technical review

Review date: 4 October 2026. Numerical source snapshot:
`45d54f29909d4026ece901c28287b23104190b1d`.

## Scope and retained explanations

The report contains 22 thematic sections, 66 static scientific figures,
seven tables, and 95 displayed equation blocks. The detailed FEM derivation
in Section 2.2, six-step spectral procedure in Section 2.5, and mathematical
explanations throughout the report are retained. Scientific assumptions,
force conventions, boundary conditions, and limitations remain explicit.
No numerical research simulations were rerun.

## Cylinder comparison table

The former Figure 19 classification graphic is replaced by a compact four-row
threshold table in Section 3.7. It compares coarse, medium, and fine meshes
with the existing literature value, using the fine mesh as a numerical
baseline for percentage differences. All differences were recalculated.
DNS decay at Reynolds number 40 and growth into shedding at 60 and 100 remain
in the synthesis text. DNS is not presented as a separately refined threshold.
Subsequent figures and tables are automatically renumbered, and the figure
manifest was updated to reflect all 66 current placements. The unused report
copy of the replaced graphic is excluded from the delivered source package;
the original research asset and prior editions are preserved.

Only the benchmark-synthesis subsection changed in the scientific source.
All other text, displayed equations, and remaining figure calls/captions were
verified byte-for-byte unchanged against the preceding source package.

## Verification

The final PDF contains 72 pages. All pages were rendered and visually inspected;
the replacement table and following page were additionally inspected at higher
resolution. Text extraction confirms consecutive figure captions 1 through 66,
valid reference markers, and text bounding boxes within page margins.
Compilation used Tectonic 0.17 to produce XDV and xdvipdfmx for the final PDF.
There are no overfull boxes, undefined references, or missing-character
warnings. Two underfull paragraph warnings remain in inspected paragraphs.

All 66 static-image SHA-256 checksums match the manifest. The source package
contains eight canonical document/build/review files and 66 static images.
Archive integrity and file bytes were checked. The delivered PDF matches the
visually inspected proof. Checksums confirm that all 117 historical main-report
and supplementary source/output files remain unchanged. The preceding integrated
PDF and source ZIP were preserved under `output/archive/` before this edit.
